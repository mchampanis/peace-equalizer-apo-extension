Peak value meters theme: Bar of colored strips on rectangles colored background.
Same theme as peak meter 3 but darker background.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.

For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.