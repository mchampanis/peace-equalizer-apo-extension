Icons theme (main icon and icons shown in the Windows system tray) as they were for version 1.6.6.0 and earlier.

Note: If a shortcut .lnk is used for any app include Peace the icon of this shortcut file is shown.
So change that icon by making a new shortcut through Peace.

Note: When starting Peace64.exe (so not by a shortcut .lnk) then the icon on the taskbar also changes.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.
For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.
