Windows 11 pastel coloring of buttons, images and other interface elements on the default Windows 11 background.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.

For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.