Configuration icons theme (icons shown in the Windows system tray) with dark blue numbers (1, 2, etc.) on blue Peace icon.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.

For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.