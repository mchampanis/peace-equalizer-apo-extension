Peak value meters theme: Colored bar on dark background.
Same as peak meter 7 but rectangular.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.

For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.