Configuration icons theme (icons shown in the Windows system tray) with black numbers (1, 2, etc.) on light grey Peace icon.
These icons are for a dark Windows taskbar.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.

For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.