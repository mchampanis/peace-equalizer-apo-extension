The Retro-Modern was made as a light theme with easy-to-read classic buttons and brushed steel-like switch. This variant has got an angular one.
 
Author: Lubomír <lh.e-mail@yandex.com or lubomir27mu@gmail.com>

The supplied graphics are meant to be used with Peace Equalizer only, unless a permission was given for other use. Else a morally right free personal disposal is allowed. You can write your opinions or suggestions to the noted e-mail of your choice or in the official forum of Peace on SourceForge.