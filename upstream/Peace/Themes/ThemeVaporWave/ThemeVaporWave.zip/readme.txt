Vapor wave theme, a certain color style of cyan, purple and blue.
The sliders and knobs and switches on the Effects panel have also this distinct coloring.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.

For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.