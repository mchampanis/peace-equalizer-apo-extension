Theme of 2 alternating slider background colors to be used on a default Windows 10 and 11 background.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.

For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.