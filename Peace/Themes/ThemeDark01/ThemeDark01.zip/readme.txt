Dark theme of sliders, knobs and switches on the Effects panel, on/off switch and peak value meter.

Since Peace version 1.6.9.1 this theme can be installed using the Peace Theme installation interface.

For former versions download zip file from the Peace website and
unzip all files to c:\program files\equalizerapo\config\theme.